EDUMAK — Cloud-connected Digital Library
========================================

This is a responsive web app/PWA for Android phones and computers.
It uses Supabase for shared accounts, books, loans, and PDF storage.

Included features
- Student registration and login
- Separate administrator login (role-controlled in Supabase)
- Admin book registration, editing, deletion, and quantity management
- Free student borrowing with a server-generated 72-hour due time
- Online return records and student activity history
- Shared PDF upload and access through private Supabase Storage
- Live refresh for book, loan, and PDF catalogue changes
- Installable PWA shell for compatible browsers

IMPORTANT
The ZIP is the app source, not a prebuilt Android APK. Cloud functions will
not work until the Supabase setup below is completed and the app is hosted
on an HTTPS website. The supplied Supabase URL is already in config.js,
but the public anon/publishable key is intentionally a placeholder.

Security
Never put a Supabase service_role/secret key in config.js. Only use the
project's public anon/publishable key. Do not share administrator passwords.

Final review note
-----------------
The SQL setup includes protected role promotion, authenticated loan returns,
and restricted RPC execution. The database, public key, hosting and device
tests still require the project owner's Supabase dashboard and deployment.
